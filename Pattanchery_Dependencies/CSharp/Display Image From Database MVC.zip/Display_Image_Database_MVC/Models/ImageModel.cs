﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Display_Image_Database_MVC.Models
{
    public class ImageModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ContentType { get; set; }
        public byte[] Data { get; set; }
        public bool IsSelected { get; set; }
    }
}